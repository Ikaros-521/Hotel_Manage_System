#ifndef TOOL_H
#define TOOL_H

#include <stdio.h>

#include "tools.h"
#include <string.h>
#include <conio.h>
//#include "getch.h"
#include <stdbool.h>

void clear_stdin(void);

char get_cmd(char start,char end);

#endif//TOOL_h
